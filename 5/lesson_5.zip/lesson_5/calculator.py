def addition(x, y):
    return x + y

def subtruction(x, y):
    return x - y

